package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// TEST MITRA Brand Colors - Vibrant Palette Theme
val PrimaryBlue = Color(0xFF1D4ED8)        // Vibrant Blue 700
val PrimaryLightBlue = Color(0xFF2563EB)   // Vibrant Blue 600
val PrimaryDarkBlue = Color(0xFF1E40AF)    // Deep Blue 800
val AccentYellow = Color(0xFFF59E0B)       // Vibrant Amber
val AccentGold = Color(0xFFD97706)         // Gold Amber

val SurfaceLight = Color(0xFFF8FAFC)       // Slate 50
val CardBackground = Color(0xFFFFFFFF)     // Clean White

// Exam Type Soft Tint Colors (Vibrant Palette)
val NavodayaBg = Color(0xFFFEF3C7)         // Amber 100
val NavodayaText = Color(0xFF78350F)       // Amber 900

val NmmsBg = Color(0xFFDBEAFE)             // Blue 100
val NmmsText = Color(0xFF1E3A8A)           // Blue 900

val Tet1Bg = Color(0xFFF3E8FF)             // Purple 100
val Tet1Text = Color(0xFF581C87)           // Purple 900

val GyanSetuBg = Color(0xFFFFE4E6)         // Rose 100
val GyanSetuText = Color(0xFF881337)       // Rose 900

val GyanSadhanaBg = Color(0xFFD1FAE5)      // Emerald 100
val GyanSadhanaText = Color(0xFF065F46)    // Emerald 900

// Legacy / Direct Category Colors
val ColorNavodaya = Color(0xFF7C3AED)      // Vibrant Violet
val ColorNMMS = Color(0xFF2563EB)          // Vibrant Blue
val ColorGyanSetu = Color(0xFF10B981)      // Emerald
val ColorGyanSadhana = Color(0xFFF59E0B)   // Amber
val ColorTET1 = Color(0xFF0D9488)          // Teal
val ColorAdminMgmt = Color(0xFFEA580C)     // Deep Orange

// Icon Container Colors
val IndigoIconBg = Color(0xFFEEF2FF)
val EmeraldIconBg = Color(0xFFECFDF5)
val AmberIconBg = Color(0xFFFEF3C7)

// Status Colors
val CorrectGreen = Color(0xFF15803D)
val CorrectGreenBg = Color(0xFFDCFCE7)
val WrongRed = Color(0xFFB91C1C)
val WrongRedBg = Color(0xFFFEE2E2)



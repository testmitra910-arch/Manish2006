package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "local_profile")
data class LocalProfileEntity(
    @PrimaryKey val id: String,
    val name: String,
    val mobileNumber: String,
    val role: String,
    val examTypeId: String? = null,
    val isMainAdmin: Boolean = false,
    val sessionToken: String = "",
    val deviceId: String = ""
)

@Entity(tableName = "local_active_test")
data class LocalActiveTestEntity(
    @PrimaryKey val attemptId: String,
    val testId: String,
    val testName: String,
    val durationMinutes: Int,
    val startTimeMillis: Long,
    val targetEndTimeMillis: Long,
    val studentId: String,
    val totalQuestions: Int,
    val isSubmitted: Boolean = false
)

@Entity(tableName = "local_test_answer")
data class LocalTestAnswerEntity(
    @PrimaryKey val id: String, // attemptId + "_" + questionId
    val attemptId: String,
    val questionId: String,
    val selectedAnswer: String?, // "A", "B", "C", "D" or null
    val updatedAtMillis: Long = System.currentTimeMillis()
)
